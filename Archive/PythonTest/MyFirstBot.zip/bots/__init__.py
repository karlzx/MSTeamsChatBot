# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .Edu_Bot import EduBot

__all__ = ["EduBot"]
